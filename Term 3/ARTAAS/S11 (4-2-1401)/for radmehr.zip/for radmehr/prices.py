main_food_list = [
    ['Kebab', 80000],
    ['Joojeh Kebab', 70000],
    ['Fesenjoon', 65000],
    ['Gheymeh', 56000],
    ['Pizza', 65000],
]

drinks_list = [
    ['orange juice',45000],
    ['barberry juice',40000],
    ['pomegranate juice',42000],
]


salad_list = [
    ['salad shirazi', 10000],
    ['salad sezar', 35000],
    ['salad fasl', 17000],
    ['salad makoroni', 26000],
    ['salad rezhimi', 29000],
    ['salad makhsos sar ashpaz', 18000],
    ['salam miveh', 16000],
]